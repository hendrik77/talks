# Demo: System-1-Entscheidungen lokal mit Kev

Drei Teile, ein durchgehender Faden: **dieselbe typisierte Entscheidung** erst im Terminal, dann in SAPs CAP-Referenz-App, dann als Router in einem Agenten-Flow.

| # | Teil | Use Case | Dauer |
|---|------|----------|-------|
| 1 | `1-triage-cli` | Ticket-Triage per CLI (Use Case 1.1) | ~3 min |
| 2 | `2-cap-incidents` | Kev im CAP-Handler der Incident-Management-App (3.1) | ~5 min |
| 3 | `3-agent-router` | Modell-Router für Coding-Aufgaben (2.1) | ~4 min |

Voraussetzungen: Node 20+, `@sap/cds-dk` global, Python 3.12+ mit `uv`, Git, `jq` und `httpie` (`brew install jq httpie`).

---

## 0 · Setup (am Vortag, M1 / 16 GB)

```bash
git clone https://github.com/jaredpalmer/kev.git && cd kev
uv sync --extra serve
uv run --extra serve python -m kev.serve --run jaredpalmer/kev-0.6b --port 8009
```

- **kev-0.6b** (Qwen3-Basis) ist auf 16 GB die sichere Wahl. 0.8B vorher messen, **4B/9B nicht** verwenden.
- Server-Flags können sich ändern – im Zweifel das Kev-README prüfen.
- Kurztest: `curl -s localhost:8009/v1/models`
- Andere System-One-Anbieter (Laya-Server, später Jev) laufen mit denselben Skripten: nur `KEV_URL`, `KEV_MODEL`, `KEV_API_KEY` setzen.

```bash
cd jev-demo/2-cap-incidents && ./apply.sh      # klont cap-js/incidents-app nach ../incidents-app und baut den Handler ein
```

**Pre-Flight am Demo-Tag:** Kev-Server starten → `node 1-triage-cli/triage.mjs` einmal laufen lassen (wärmt das Modell auf) → `cds watch` in `incidents-app` → Terminal-Schrift groß, zwei Terminals nebeneinander (links Befehle, rechts `cds watch`-Log).

---

## 1 · Ticket-Triage im Terminal

**Schritt 1 – rohes HTTP** („das ist alles, ein POST“). Die Fragen liegen in `questions.json`, nur das Ticket ändert sich.

HTTPie (am lesbarsten auf der Bühne, `:=@` bettet die Datei als JSON ein):
```bash
cd 1-triage-cli
http :8009/v1/systemone model=kev-latest \
  state="Our inverter started smoking this morning." \
  questions:=@questions.json
```

curl (Body per `jq`, kein Escaping nötig):
```bash
jq -n --arg s "Our inverter started smoking this morning." \
  --slurpfile q questions.json '{model:"kev-latest", state:$s, questions:$q[0]}' \
| curl -s localhost:8009/v1/systemone -H 'content-type: application/json' -d @- | jq
```

Kompakt, eine Zeile pro Frage (Filter liegt in `compact.jq`):
```bash
http --body :8009/v1/systemone model=kev-latest state="Our inverter started smoking this morning." \
  questions:=@questions.json | jq -rf compact.jq
```
```
urgency: high  (conf 0.81)
department: technical  (conf 0.64)
human_now: 0.88  (conf -)
frustration: 1.2  (conf 0.55)
```
(Werte beispielhaft.)

**Schritt 2 – dieselbe Anfrage mit Balken:**
```bash
node triage.mjs "Our inverter started smoking and the house smells like burnt plastic."
node triage.mjs "URGENT!!! The app shows the wrong colour for the battery icon."
node triage.mjs --raw "Could you send me a copy of my invoice?"
```

**Was zeigen**
- Vier Fragen (choice, choice, noul, score) in **einem** Call, Antworten mit Wahrscheinlichkeiten, 0 Output-Tokens.
- Das zweite Ticket: Großbuchstaben und „URGENT“, aber inhaltlich kosmetisch. Hier sieht man, ob das Modell den Inhalt oder das Schreien bewertet.
- HTTPie/curl und `triage.mjs` treffen denselben Server mit denselben Fragen. Die **Anwendung** definiert die erlaubten Antworten.

**Überleitung:** „Die Frage `urgency` nehmen wir jetzt 1:1 und bauen sie in SAPs eigene Referenz-App ein.“

---

## 2 · CAP: SAP Incident Management

Basis ist [cap-js/incidents-app](https://github.com/cap-js/incidents-app), die Referenz-App aus dem SAP BTP Developer’s Guide. Dort setzt ein Handler die Dringlichkeit per Regex:

```js
let urgent = req.data.title?.match(/urgent/i)
if (urgent) req.data.urgency_code = 'H'
```

**Code zeigen** (`srv/processor-service.js`), drei Punkte:
1. **Das CDS-Enum ist das Schema.** `Urgency.elements.code.enum` liefert `high/medium/low` → daraus werden die Optionen. Das Modell kann nur Werte liefern, die im Datenmodell existieren.
2. **Schwelle entscheidet, ob Code handelt.** `confidence ≥ KEV_THRESHOLD` → Wert setzen, sonst Default und Log „manuelle Prüfung“.
3. **Die alte Regex bleibt als Fallback.** Kev offline → Verhalten wie vorher. Die mitgelieferten Tests der App laufen weiter grün.

**Live**
```bash
cd ../incidents-app && cds watch                     # rechtes Terminal: Log beobachten
../jev-demo/2-cap-incidents/create-incident.sh "Inverter is smoking, smell of burnt plastic"
../jev-demo/2-cap-incidents/create-incident.sh "Not urgent: please send a copy of my invoice"
../jev-demo/2-cap-incidents/create-incident.sh "Strange issue" "the inverter is smoking"
```
Alternativ in der Fiori-App (`/incidents/webapp`, Login `alice`) ein Incident anlegen und speichern.

Im Log steht pro Incident der direkte Vergleich (Werte beispielhaft):
```
[kev] - "Not urgent: please send a copy of my invoice"  regex→H  kev→L  conf 0.83  190 ms
```
Das ist der Moment für das Publikum: Die Regex liegt garantiert einmal falsch positiv („Not urgent“ → High) und einmal falsch negativ (Rauch ohne das Wort „urgent“). Ob Kev es besser macht, vorher auf dem M1 prüfen – und wenn nicht, genau das zeigen.

**Pointe fürs Publikum:** Beim Stichwort Konfidenz auf die Kalibrierungsfolie zurückverweisen: Die Schwelle 0.5 ist hier gesetzt, in einem Projekt wird sie auf Kundendaten im Shadow Mode bestimmt.

Konfiguration: `KEV_URL`, `KEV_MODEL`, `KEV_API_KEY`, `KEV_THRESHOLD` (0.5), `KEV_TIMEOUT_MS` (5000).
Hinweis: Kevs `confidence` ist normiert, `(p_max − 1/K) / (1 − 1/K)`. Bei drei Optionen entspricht 0.5 also p ≈ 0.67.

---

## 3 · Agentic Flow: Router spart Geld

```bash
cd ../jev-demo/3-agent-router
node router.mjs                                        # Schätzung, kein API-Key nötig
ANTHROPIC_API_KEY=… node router.mjs --live --app ../incidents-app   # echte Calls, echte Tokens
```

Zehn Aufgaben für genau die App aus Teil 2 (`tasks.json`, frei anpassbar). Kev beantwortet pro Aufgabe zwei Fragen:
- `tier` (trivial / standard / complex) → Haiku 4.5 / Sonnet 5 / Opus 5.5
- `risky` (Auth, personenbezogene Daten, Löschen?) → immer das größte Modell **plus** Mensch im Loop

Ist Kev unsicher, geht die Aufgabe eine Stufe **hoch**, nie runter. Am Ende steht die Kostenersparnis gegenüber „alles an Opus“ und die Hochrechnung.

**Was sagen**
- Die Ersparnis hängt vom Aufgabenmix ab. Mit der Beispielliste (4 von 10 komplex/riskant) ist sie moderat, mit typischem Alltags-Backlog deutlich höher.
- Die ehrliche Einschränkung steht im Output: Ob die Qualität hält, beweist erst ein Eval. Das passt zur Folie mit der Kaskaden-Studie, die den Nutzen noch nicht statistisch belegen konnte.
- Preise stehen oben in `router.mjs`: vor dem Talk auf anthropic.com/pricing prüfen.

---

## Plan B

- Jeden Teil vorher als Bildschirmvideo aufnehmen.
- Kev fällt aus → Teil 2 läuft trotzdem (Regex-Fallback, Log zeigt „Kev nicht erreichbar“). Das ist selbst ein gutes Architektur-Argument.
- Latenz schwankt auf dem M1: vor dem Talk einmal alle drei Teile durchspielen, damit das Modell warm ist.
