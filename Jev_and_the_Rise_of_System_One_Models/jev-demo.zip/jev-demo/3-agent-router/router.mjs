#!/usr/bin/env node
// Teil 3 – System 1 routet, System 2 arbeitet.
// Kev entscheidet pro Coding-Aufgabe, welches LLM sie bekommt. Vergleich: "alles an das größte Modell".
//
//   node router.mjs                         Routing + Kostenschätzung (kein API-Key nötig)
//   node router.mjs --live --app ../incidents-app
//                                           führt die Aufgaben wirklich mit Claude aus (ANTHROPIC_API_KEY),
//                                           echte Token-Zahlen; Dateien der CAP-App als Kontext
// Env: KEV_URL, KEV_MODEL, KEV_THRESHOLD (default 0.5), ANTHROPIC_API_KEY

import { readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const KEV_URL = process.env.KEV_URL ?? 'http://127.0.0.1:8009'
const KEV_MODEL = process.env.KEV_MODEL ?? 'kev-latest'
const THRESHOLD = Number(process.env.KEV_THRESHOLD ?? 0.5)
const LIVE = process.argv.includes('--live')
const APP = process.argv.includes('--app') ? process.argv[process.argv.indexOf('--app') + 1] : null

// USD pro 1M Tokens (input/output). Vor dem Talk auf anthropic.com/pricing prüfen!
const MODELS = {
  trivial:  { id: 'claude-haiku-4-5-20251001', name: 'Haiku 4.5', in: 1, out: 5 },
  standard: { id: 'claude-sonnet-5',           name: 'Sonnet 5',  in: 2, out: 10 },
  complex:  { id: 'claude-opus-5-5',           name: 'Opus 5.5',  in: 4, out: 20 },
}
const TIERS = Object.keys(MODELS)
const BASELINE = MODELS.complex
// Annahmen für den Schätzmodus (Kontext + Antwort je Aufgabentyp) – im Live-Modus echte Werte
const EST_TOKENS = { trivial: [3000, 400], standard: [6000, 1500], complex: [10000, 4000] }

const TASKS = JSON.parse(readFileSync(new URL('./tasks.json', import.meta.url)))

const QUESTIONS = {
  tier: {
    type: 'choice',
    instructions: 'How demanding is this software engineering task?',
    criteria: {
      trivial: 'Cosmetic or one-line change: text, label, typo, config value',
      standard: 'Normal feature or bugfix inside one module with clear requirements',
      complex: 'Cross-cutting design: architecture, multi-tenancy, workflows, migrations, performance',
    },
  },
  risky: { type: 'noul', instructions: 'Does this task touch authentication, authorization, personal data or deletion of data?' },
}

const c = { dim: s => `\x1b[2m${s}\x1b[0m`, b: s => `\x1b[1m${s}\x1b[0m`, g: s => `\x1b[32m${s}\x1b[0m`, y: s => `\x1b[33m${s}\x1b[0m`, m: s => `\x1b[35m${s}\x1b[0m` }
const usd = x => `$${x.toFixed(4)}`
const cost = (m, [i, o]) => (i * m.in + o * m.out) / 1e6

async function kev(state) {
  const t0 = performance.now()
  const r = await fetch(`${KEV_URL}/v1/systemone`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ model: KEV_MODEL, state, questions: QUESTIONS }),
  })
  if (!r.ok) throw new Error(`Kev ${r.status}`)
  return { ...(await r.json()), ms: performance.now() - t0 }
}

function route({ answers: { tier, risky } }) {
  if (risky.noul >= 0.5) return { tier: 'complex', why: `risky ${risky.noul.toFixed(2)} → größtes Modell + 👤 Review`, review: true }
  if (tier.confidence < THRESHOLD) {
    const up = TIERS[Math.min(TIERS.indexOf(tier.choice) + 1, TIERS.length - 1)]
    return { tier: up, why: `${tier.choice} unsicher (${tier.confidence.toFixed(2)}) → eine Stufe hoch` }
  }
  return { tier: tier.choice, why: `${tier.choice} (${tier.confidence.toFixed(2)})` }
}

const context = APP && existsSync(APP)
  ? ['db/schema.cds', 'srv/processor-service.cds', 'srv/processor-service.js']
      .filter(f => existsSync(join(APP, f)))
      .map(f => `--- ${f}\n${readFileSync(join(APP, f), 'utf8')}`).join('\n')
  : ''

async function claude(model, task) {
  const t0 = performance.now()
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: model.id, max_tokens: 4000,
      system: 'You are a senior SAP CAP (Node.js) developer. Answer with a concise unified diff against the project files, nothing else.',
      messages: [{ role: 'user', content: `${context}\n\nTask: ${task}` }],
    }),
  })
  if (!r.ok) throw new Error(`Claude ${r.status}: ${await r.text()}`)
  const j = await r.json()
  return { tokens: [j.usage.input_tokens, j.usage.output_tokens], ms: performance.now() - t0 }
}

if (LIVE && !process.env.ANTHROPIC_API_KEY) { console.error('--live braucht ANTHROPIC_API_KEY'); process.exit(1) }
console.log(c.b(`\nSystem 1 (Kev, lokal) routet ${TASKS.length} Aufgaben · Baseline: alles an ${BASELINE.name}`) +
  c.dim(`  ${LIVE ? 'LIVE – echte Token' : 'Schätzung – Token-Annahmen je Typ'} · Schwelle ${THRESHOLD}\n`))

let routed = 0, baseline = 0, kevMs = 0
const perModel = {}
for (const task of TASKS) {
  let k
  try { k = await kev(task) } catch (e) {
    console.error(`Kev nicht erreichbar unter ${KEV_URL} (${e.message})`); process.exit(1)
  }
  kevMs += k.ms
  const r = route(k), model = MODELS[r.tier]
  const run = LIVE ? await claude(model, task) : { tokens: EST_TOKENS[r.tier] }
  const cr = cost(model, run.tokens), cb = cost(BASELINE, run.tokens)
  routed += cr; baseline += cb
  perModel[model.name] = (perModel[model.name] ?? 0) + 1
  const tag = r.review ? c.m(model.name) : model === BASELINE ? c.y(model.name) : c.g(model.name)
  console.log(`${c.b('•')} ${task}`)
  console.log(`  ${c.dim(`Kev ${k.ms.toFixed(0)} ms:`)} ${r.why}  →  ${tag}  ${usd(cr)} ${c.dim(`statt ${usd(cb)}`)}` +
    (LIVE ? c.dim(`  (${run.tokens[0]}/${run.tokens[1]} tok, ${(run.ms / 1000).toFixed(1)} s)`) : ''))
}

const saved = 1 - routed / baseline
console.log('\n' + c.b('Ergebnis'))
console.log(`  Verteilung:      ${Object.entries(perModel).map(([m, n]) => `${m} ×${n}`).join(' · ')}`)
console.log(`  Routing-Kosten:  ${usd(routed)}   vs.  alles ${BASELINE.name}: ${usd(baseline)}`)
console.log(`  Ersparnis:       ${c.g(c.b(`${(saved * 100).toFixed(0)} %`))}   · Kev-Overhead: ${kevMs.toFixed(0)} ms gesamt, $0`)
console.log(`  Hochgerechnet:   1.000 Aufgaben/Tag ≈ ${c.b(`$${((baseline - routed) / TASKS.length * 1000 * 30).toFixed(0)}`)} gespart pro Monat`)
console.log(c.dim('  Hinweis: gleiche Token-Mengen für beide Seiten angenommen; ob die Qualität hält, zeigt erst ein Eval auf echten Tasks.\n'))
