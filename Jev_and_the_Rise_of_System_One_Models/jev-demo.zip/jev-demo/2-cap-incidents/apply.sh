#!/usr/bin/env bash
# Holt SAPs Incident-Management-Referenz-App (cap-js/incidents-app) und baut den Kev-Handler ein.
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
TARGET=${1:-$HERE/../incidents-app}

[ -d "$TARGET" ] || git clone https://github.com/cap-js/incidents-app "$TARGET"
cd "$TARGET"
npm install
cp "$HERE/srv/kev.js" "$HERE/srv/processor-service.js" srv/
echo; git --no-pager diff --stat; echo
echo "Fertig. Start:  cd $TARGET && cds watch   →  http://localhost:4004/incidents/webapp  (Login: alice)"
