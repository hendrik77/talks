// Minimaler Client für die System-One-API (Jev-kompatibel: Kev lokal, Laya, oder TypeSafe Jev).
// Wechsel des Anbieters = nur KEV_URL / KEV_MODEL / KEV_API_KEY ändern.
const cds = require('@sap/cds')
const LOG = cds.log('kev')

const { KEV_URL = 'http://127.0.0.1:8009', KEV_MODEL = 'kev-latest', KEV_API_KEY, KEV_TIMEOUT_MS = '5000' } = process.env

async function decide(state, questions) {
  const t0 = performance.now()
  const res = await fetch(`${KEV_URL}/v1/systemone`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(KEV_API_KEY && { authorization: `Bearer ${KEV_API_KEY}` }) },
    body: JSON.stringify({ model: KEV_MODEL, state, questions }),
    signal: AbortSignal.timeout(Number(KEV_TIMEOUT_MS)),
  })
  if (!res.ok) throw new Error(`Kev ${res.status}: ${await res.text()}`)
  const { answers } = await res.json()
  return { answers, ms: Math.round(performance.now() - t0) }
}

module.exports = { decide, LOG }
