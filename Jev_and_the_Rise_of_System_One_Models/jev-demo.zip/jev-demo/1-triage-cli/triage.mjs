#!/usr/bin/env node
// Teil 1 – Ticket-Triage im Terminal gegen ein lokales, Jev-kompatibles Modell (Kev).
// Nutzung:
//   node triage.mjs "Inverter is smoking and smells like burnt plastic!"
//   node triage.mjs            -> spielt die Beispiel-Tickets unten durch
//   node triage.mjs --raw "…"  -> zeigt Request + rohe JSON-Antwort
// Env: KEV_URL (default http://127.0.0.1:8009), KEV_MODEL (default kev-latest), KEV_API_KEY (optional)

const KEV_URL = process.env.KEV_URL ?? 'http://127.0.0.1:8009'
const KEV_MODEL = process.env.KEV_MODEL ?? 'kev-latest'

// Gleiche Domäne wie die SAP Incidents-App (ACME, Solaranlagen) -> nahtloser Übergang zu Teil 2
const EXAMPLES = [
  'Our inverter started smoking this morning and the whole house smells like burnt plastic.',
  'Hi, could you send me a copy of last month\'s invoice? No rush.',
  'Solar panel output dropped by about 30% since the storm last week. Everything else works.',
  'URGENT!!! The app shows the wrong colour for the battery icon.',
]

// Das "Schema" der Entscheidung – genau das definiert die Anwendung, nicht das Modell
const QUESTIONS = {
  urgency: {
    type: 'choice',
    instructions: 'How urgent is this incident for the support team?',
    criteria: {
      high: 'Safety risk (fire, smoke, electric shock) or complete outage',
      medium: 'Degraded function, a workaround exists',
      low: 'Question, paperwork or cosmetic issue',
    },
  },
  department: {
    type: 'choice',
    instructions: 'Which team should handle this?',
    criteria: {
      technical: 'Hardware or software malfunction',
      billing: 'Invoices, payments, contracts',
      field_service: 'Needs a technician on site',
    },
  },
  human_now: { type: 'noul', instructions: 'Does a human need to look at this within the next hour?' },
  frustration: {
    type: 'score',
    instructions: 'How frustrated is the customer?',
    criteria: ['Calm', 'Annoyed', 'Very angry'],
  },
}

const c = { dim: s => `\x1b[2m${s}\x1b[0m`, b: s => `\x1b[1m${s}\x1b[0m`, g: s => `\x1b[32m${s}\x1b[0m`, y: s => `\x1b[33m${s}\x1b[0m`, r: s => `\x1b[31m${s}\x1b[0m` }
const bar = p => '█'.repeat(Math.round(p * 20)).padEnd(20, '░')
const pct = p => `${(p * 100).toFixed(0).padStart(3)}%`
const color = p => (p >= 0.7 ? c.g : p >= 0.4 ? c.y : c.r)

async function ask(state) {
  const body = { model: KEV_MODEL, state, questions: QUESTIONS }
  const t0 = performance.now()
  const res = await fetch(`${KEV_URL}/v1/systemone`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(process.env.KEV_API_KEY && { authorization: `Bearer ${process.env.KEV_API_KEY}` }) },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`)
  return { body, json: await res.json(), ms: performance.now() - t0 }
}

function print(state, { json, ms }) {
  console.log('\n' + c.b('Ticket: ') + state)
  for (const [id, a] of Object.entries(json.answers)) {
    if (a.type === 'noul') {
      console.log(`  ${id.padEnd(12)} ${c.b(a.noul >= 0.5 ? 'YES' : 'no ')}   ${color(Math.abs(a.noul - 0.5) * 2)(bar(a.noul))} ${pct(a.noul)}`)
      continue
    }
    const levels = Object.keys(a.legend ?? {}).length ? a.legend : QUESTIONS[id]?.criteria ?? {}
    const head = a.type === 'choice' ? a.choice : levels[Math.round(a.score)] ?? a.score
    console.log(`  ${id.padEnd(12)} ${c.b(String(head))}  ${c.dim(`confidence ${a.confidence?.toFixed(2)}`)}`)
    for (const [opt, p] of Object.entries(a.probabilities ?? {})) {
      const label = a.type === 'score' ? levels[opt] ?? opt : opt
      console.log(`    ${String(label).padEnd(14)} ${color(p)(bar(p))} ${pct(p)}`)
    }
  }
  console.log(c.dim(`  ⏱  ${ms.toFixed(0)} ms (Server: ${json.latency_ms ?? '?'} ms) · 0 Output-Tokens · lokal · $0`))
}

const args = process.argv.slice(2)
const raw = args[0] === '--raw' && args.shift()
const tickets = args.length ? [args.join(' ')] : EXAMPLES

try {
  for (const t of tickets) {
    const r = await ask(t)
    if (raw) console.log(c.dim('→ ' + JSON.stringify(r.body, null, 2)), '\n' + JSON.stringify(r.json, null, 2))
    else print(t, r)
  }
} catch (e) {
  console.error(c.r(`Kev nicht erreichbar unter ${KEV_URL}: ${e.message}`))
  console.error('Server starten:  uv run --extra serve python -m kev.serve --run jaredpalmer/kev-0.6b --port 8009')
  process.exit(1)
}
