# Eine Zeile pro Frage: Antwort + Konfidenz (gerundet)
.answers | to_entries[] | .value as $a
| "\(.key): \($a.choice // (($a.noul // $a.score) * 100 | round / 100))  (conf \(if $a.confidence then ($a.confidence * 100 | round / 100) else "-" end))"
