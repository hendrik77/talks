#!/usr/bin/env bash
# Legt ein Incident per OData an (Draft anlegen + aktivieren, wie die Fiori-App) und zeigt die Dringlichkeit.
# Nutzung: ./create-incident.sh "Inverter is smoking" ["optionale erste Nachricht"]
set -euo pipefail
BASE=${CAP_URL:-http://localhost:4004}/odata/v4/processor/Incidents
AUTH=alice:
TITLE=${1:?Titel fehlt}; MSG=${2:-}

BODY=$(TITLE="$TITLE" MSG="$MSG" node -e '
  const b = { title: process.env.TITLE, customer_ID: "1004100" }
  if (process.env.MSG) b.conversation = [{ ID: crypto.randomUUID(), message: process.env.MSG }]
  console.log(JSON.stringify(b))')

ID=$(curl -sf -u $AUTH -H 'content-type: application/json' -d "$BODY" "$BASE" | node -pe 'JSON.parse(require("fs").readFileSync(0)).ID')
curl -sf -u $AUTH -X POST -H 'content-type: application/json' -d '{}' \
  "$BASE(ID=$ID,IsActiveEntity=false)/ProcessorService.draftActivate" >/dev/null
curl -sf -u $AUTH "$BASE(ID=$ID,IsActiveEntity=true)?\$select=title&\$expand=urgency(\$select=descr)" \
  | node -pe 'const r=JSON.parse(require("fs").readFileSync(0)); `→ ${r.title}\n  urgency: ${r.urgency.descr}`'
