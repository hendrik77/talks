const cds = require('@sap/cds')
const { decide, LOG } = require('./kev')

// Beschreibungen helfen dem Modell – die Optionen selbst kommen aus dem CDS-Modell
const HINTS = {
  high:   'Safety risk (fire, smoke, electric shock) or complete outage',
  medium: 'Degraded function, a workaround exists',
  low:    'Question, paperwork or cosmetic issue',
}
const THRESHOLD = Number(process.env.KEV_THRESHOLD ?? 0.5)

class ProcessorService extends cds.ApplicationService {
  init() {

    const { Incidents } = this.entities
    const { Urgency } = cds.entities('sap.capire.incidents')
    const LEVELS = Urgency.elements.code.enum  // { high:{val:'H'}, medium:{val:'M'}, low:{val:'L'} }

    this.before ('UPDATE', Incidents, async req => {
      let closed = await SELECT.one(1) .from (req.subject) .where `status.code = 'C'`
      if (closed) req.reject `Can't modify a closed incident!`
    })

    // System 1: Kev entscheidet die Dringlichkeit – typisiert, lokal, ohne Output-Tokens
    this.before ('CREATE', Incidents, async req => {
      const { title, conversation = [] } = req.data
      if (!title) return
      const regex = /urgent/i.test(title) ? 'H' : undefined   // alte Regel: Baseline & Fallback
      const state = [title, ...conversation.map(m => m.message)].filter(Boolean).join('\n')

      try {
        const { answers: { urgency: a }, ms } = await decide(state, {
          urgency: {
            type: 'choice',
            instructions: 'How urgent is this incident for the support team?',
            criteria: Object.fromEntries(Object.keys(LEVELS).map(k => [k, HINTS[k] ?? null])),
          },
        })
        const code = LEVELS[a.choice].val
        LOG.info(`"${title}"  regex→${regex ?? '–'}  kev→${code}  conf ${a.confidence.toFixed(2)}  ${ms} ms`)

        if (a.confidence >= THRESHOLD) {
          req.data.urgency_code = code                       // Code handelt
        } else {
          if (regex) req.data.urgency_code = regex           // unsicher → Regel bzw. Default 'M'
          LOG.info(`  ↳ Konfidenz < ${THRESHOLD} → manuelle Prüfung`)
        }
      } catch (e) {
        LOG.warn(`Kev nicht erreichbar (${e.message}) → Regex-Fallback`)
        if (regex) req.data.urgency_code = regex
      }
    })
    // Bei UPDATE entscheidet bewusst der Mensch – keine automatische Überschreibung.

    return super.init()
  }
}

module.exports = { ProcessorService }
